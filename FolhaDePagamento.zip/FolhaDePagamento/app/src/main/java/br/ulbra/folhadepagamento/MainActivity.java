package br.ulbra.folhadepagamento;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

        EditText edtNome, edtSalario,edtFilhos;
        RadioGroup rg;
        RadioButton rbtnFeminino, rbtnMasculino;
        Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        edtNome = findViewById(R.id.edtNome);
        edtSalario = findViewById(R.id.edtSalario);
        edtFilhos = findViewById(R.id.edtFilhos);
        rg = findViewById(R.id.rg);
        rbtnFeminino = findViewById(R.id.rbtnFeminino);
        rbtnMasculino = findViewById(R.id.rbtnMasculino);
        btnCalcular = findViewById(R.id.btnCalcular);


        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double salario = 0, filho =0, inss =0, ir= 0, sf =0, result =0;
                    String nome;
                     salario = Double.parseDouble(edtSalario.getText().toString());
                     filho = Double.parseDouble(edtFilhos.getText().toString());
                     nome = edtNome.getText().toString();

                     if (salario<=1212){
                         inss = (salario*7.6) / 100;
                     }else if (salario == 1212.01 && salario <= 2427.35){
                        inss = (salario*9) / 100;
                    }else if (salario == 2427.36 && salario<= 3641.03){
                         inss = (salario*12)/100;
                     } else if (salario == 3641.04 && salario<= 7087.22){
                    inss = (salario*14)/100;
                }
                     if (salario <=1903.98){
                         ir = 0;
                     } else if (salario == 1903.99 && salario <= 2826.65){
                        ir = (salario*7.5)/ 100;
                     }else if (salario == 2826.66 && salario <= 3751.05){
                         ir = (salario*15)/ 100;
                     } else if (salario == 3751.06 && salario <= 4664.68) {
                         ir = (salario * 22.5) / 100;
                }
                     if(salario<= 1212){
                        sf = (filho * 56.47);
                     }

                     result = salario - (inss + ir) +sf;

                     int op = rg.getCheckedRadioButtonId();
                     if (op == R.id.rbtnFeminino){
                         Toast.makeText(MainActivity.this, "Sra." + nome + ", seu salário liquido é: R$ " + result + "foram descotados os valores do INSS e IR." + inss + "reais e " + ir + "reais" + " O salário família é de: R$ " + sf, Toast.LENGTH_LONG).show();
                     }else if (op == R.id.rbtnMasculino){
                         Toast.makeText(MainActivity.this, "Sr." + nome + ", seu salário liquido é: R$ " + result + "foram descotados os valores do INSS e IR." + inss + "reais e " + ir + "reais" + " O salário família é de: R$ " + sf, Toast.LENGTH_LONG).show();
                     }


                }catch (IllegalArgumentException E){
                    Toast.makeText(MainActivity.this, "Tente novamente! Erro no(s) campo(s) não preenchido(s) ou valor negativo adicionado ", Toast.LENGTH_LONG).show();
                }
/*
               try {
                    double salario, filho;
                    String nome;
                    salario = Double.parseDouble(edtSalario.getText().toString());
                    filho = Double.parseDouble(edtFilhos.getText().toString());
                    nome = edtNome.getText().toString();


                }catch (Exception E){
                   Toast.makeText(MainActivity.this, "Preencha o campo salário", Toast.LENGTH_SHORT).show();
             E.getMessage()
                }*/
            }

            });


        };

        };

